declare module "@salesforce/apex/FlexCardController.getFlowLabel" {
  export default function getFlowLabel(param: {flowApiNames: any}): Promise<any>;
}
