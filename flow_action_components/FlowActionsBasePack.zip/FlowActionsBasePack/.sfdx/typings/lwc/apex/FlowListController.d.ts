declare module "@salesforce/apex/FlowListController.getFlowNamesApex" {
  export default function getFlowNamesApex(param: {filtersString: any}): Promise<any>;
}
