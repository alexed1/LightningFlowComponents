({
    init: function(cmp) {
        cmp.set('v.myVal', '<b>Hello!</b>');
    }
})
