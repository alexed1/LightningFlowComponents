declare module "@salesforce/apex/FieldSelectorController.getObjectFields" {
  export default function getObjectFields(param: {objectName: any}): Promise<any>;
}
